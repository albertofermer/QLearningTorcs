module AAAAAAA {
	requires java.desktop;
}